SWUKY WEBSITE PROTOTYPE v0.1

OPEN IT LOCALLY
1. Unzip Swuky_Website_v1.zip
2. Open index.html
3. The site will open in your web browser.

CURRENTLY INCLUDED
- SWUKY branding
- Responsive homepage
- Discover section
- Pacific City featured world
- Creator section
- Safety section
- Signup/login prototype UI
- Username preview

IMPORTANT
This is a front-end prototype only.
It does NOT store accounts, passwords, email addresses, or other user data.

TO MAKE SWUKY A REAL PUBLIC WEBSITE
PHASE 1
- Choose and buy a domain
- Deploy these files to a static host such as Cloudflare Pages, Netlify, or Vercel
- Connect the domain

PHASE 2
- Add real authentication using a reputable auth provider
- Add a database
- Create profile pages
- Add avatar data
- Add a real Discover/game page

PHASE 3
- Creator accounts
- Game uploads / publishing pipeline
- Moderation systems
- Parental controls and age-aware experiences
- Desktop game client / launcher

SECURITY NOTE
Never store plaintext passwords.
Do not turn the current prototype form into real authentication without a secure backend/authentication system.
